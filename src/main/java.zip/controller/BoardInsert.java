package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.BoardDAO;

@WebServlet("/boardInsert")
public class BoardInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/* String line = System.getProperty("line.separator"); */

		
		String bod_title = request.getParameter("bod_title");
		String bod_writer = request.getParameter("bod_writer");
		String bod_content = request.getParameter("bod_content");
		String bod_password = request.getParameter("bod_password");
		/*
		 * bod_content = bod_content.replaceAll("\n", line);
		 */
		
		BoardDAO dao = new BoardDAO();
		dao.boardInsert(bod_title, bod_writer, bod_content, bod_password);
		
		response.sendRedirect("/project/BoardSelect");
		
		
	}

}
